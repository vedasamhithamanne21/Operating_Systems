

#include <sys/wait.h>
#include <stdint.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>


char input[200]; 
char *command; 
char *args[20]; 
int ct, ct2; 
char *arg; 
char *paths[4]; 
int opened = 0; 
FILE *fp; 
FILE *temp_fp;

// fat32 variables
int16_t byte_sec; 
int8_t sec_clus; 
int16_t Rs_sec_cnt; 
int8_t Num_Fat; 
int32_t Fat32; 

//Extra variables used for accessing 
char Name[8]; 




int16_t Root_Ent_Cnt; 
char Val_lab[11]; 

int32_t Root_clus; 

int32_t Root_Dir_Cluster_Address = 0; 
int32_t Current_Dir_Cluster_Address = 0; 

//struct to hold all of the entry data
struct EntryData {
    char D_Name[12];
    uint8_t D_Att;
    uint8_t Unused1[8];
    uint16_t DIR_FirstClusterHigh;
    uint8_t Unused2[4];
    uint16_t DIR_FirstClusterLow;
    uint32_t DIR_FileSize;
};

struct EntryData dir[16]; 


void get() {
    
    fgets(input, 200, stdin );
    
    if(strlen(input) != 1)
        input[strcspn(input, "\n")] = 0;
}


void cntl_c_handler(int signal) {
    // explain proper exit procedure to user
    printf("\nPlease user \"exit\" or \"quit\" to exit the mav shell\nmsh>");
    fflush(stdout);
}


void cntl_z_handler(int signal) {
    // explain proper exit procedure to user
    printf("\nPlease user \"exit\" or \"quit\" to exit the mav shell\nmsh>");
    fflush(stdout);
}


void make_name(char* D_Name){
    int whitespace = 11 - strlen(D_Name);
    //uppercase everything
    for(ct = 0; ct < 11; ct ++){
        D_Name[ct] = toupper(D_Name[ct]);
    }
    //add whitespace
    for(ct = 0; ct < whitespace; ct ++){
        strcat(D_Name, " ");
    }
}


void make_file(char* file_name){
    char * token; 
    char result[20]; 
    int whitespace = 8; 
    
    token = strtok(file_name, ".");
    if(strlen(token) > 8 || token == NULL){
        printf("Invalid filename\n");
        return;
    }
    
    strcpy(result, token);
    
    token = strtok(NULL, ""); 
    if(strlen(token) > 3 || token == NULL){
        printf("Invalid extension for filename\n");
        return;
    }
    
    whitespace -= strlen(result);
    for(ct = 0; ct < whitespace; ct ++){
       strcat(result, " ");
    }
    //calculate whitespace for the extension and then add both on
    whitespace = 3 - strlen(token);
    strcat(result, token);
    for(ct = 0; ct < whitespace; ct ++){
        strcat(result, " ");
    }
    result[11] = 0;
    //uppercase everything
    for(ct = 0; ct < 11; ct ++){
        result[ct] = toupper(result[ct]);
    }
    //copy that back into filename
    strcpy(file_name, result);
}


void populate_dir(int DirectoryAddress, struct EntryData* direct) {
    fseek(fp, DirectoryAddress, SEEK_SET);
    for(ct = 0; ct < 16; ct ++){
        fread(direct[ct].D_Name, 1, 11, fp);
        direct[ct].D_Name[11] = 0;
        fread(&direct[ct].D_Att, 1, 1, fp);
        fread(&direct[ct].Unused1, 1, 8, fp);
        fread(&direct[ct].DIR_FirstClusterHigh, 2, 1, fp);
        fread(&direct[ct].Unused2, 1, 4, fp);
        fread(&direct[ct].DIR_FirstClusterLow, 2, 1, fp);
        fread(&direct[ct].DIR_FileSize, 4, 1, fp);
    }
}


void open(char* filename) {
    
    fp = fopen(filename, "r");

    
    if(fp != NULL){
        printf("Opened %s\n", filename);
        opened = 1;

        //grab all of BPB variables
        fseek(fp, 3, SEEK_SET);
        fread(Name, 1, 8, fp);
        fread(&byte_sec, 1, 2, fp);
        fread(&sec_clus, 1, 1, fp);
        fread(&Rs_sec_cnt, 1, 2, fp);
        fread(&Num_Fat, 1, 1, fp);
        fread(&Root_Ent_Cnt, 1, 2, fp);
        fseek(fp, 36, SEEK_SET);
        fread(&Fat32, 1, 4, fp);
        fseek(fp, 44, SEEK_SET);
        fread(&Root_clus, 1, 4, fp);
        fseek(fp, 71, SEEK_SET);
        fread(Val_lab, 1, 11, fp); 

        //calculate the root directory location
        Root_Dir_Cluster_Address = (Num_Fat * Fat32 * byte_sec) +
                             (Rs_sec_cnt * byte_sec);

        //start off in the root directory
        Current_Dir_Cluster_Address = Root_Dir_Cluster_Address;

        //fill dir by going to the address and reading in the data to structs
        populate_dir(Current_Dir_Cluster_Address, dir);
    }
    else
        printf("Could not locate file\n");

}


int16_t next_lb(int16_t sector){
    uint32_t FATAddr = (Rs_sec_cnt * byte_sec) + (sector * 4);
    int16_t val;
    fseek(fp, FATAddr, SEEK_SET);
    fread(&val, 2, 1, fp);
    return val;
}


int LBtoAddr(int32_t sector){
    if(!sector)
        return Root_Dir_Cluster_Address;
    return (byte_sec * Rs_sec_cnt) + ((sector - 2) * byte_sec) + (byte_sec * Num_Fat * Fat32);
}


void ls() {
    char *token; 
    char tempname[15]; 
    char dirname[15];
    int32_t tempAddr = Current_Dir_Cluster_Address; 
    struct EntryData tempdir[16];   
    int found; 
    
    if(!opened){
        printf("There is no filesystem open.\n");
        return;
    }
    
    if(args[0] == NULL || !strcmp(args[0],".")){
        for(ct = 0; ct < 16; ct ++){
            //if the attribute is 1, 16, 32 then we show it
            if(dir[ct].D_Att == 1  ||
               dir[ct].D_Att == 16 ||
               dir[ct].D_Att == 32 ){
                printf("%s    %d Bytes\n", dir[ct].D_Name, dir[ct].DIR_FileSize);   
            }   
        }
        return;
    }
    
    token = strtok(args[0], "/");
    while(token != NULL){
        //check to see if it is valid
        if(strlen(token) > 12){
            printf("Directory does not exist\n");
            return;
        }
        						       
        strcpy(tempname, token);
        make_name(tempname);      
        //populate the current directory for ease
        populate_dir(tempAddr, tempdir);
        //check it against the current directory
        found = 0;
        for(ct = 0; ct < 16; ct ++){
            if(!strcmp(tempdir[ct].D_Name, tempname)){
                tempAddr = LBtoAddr(tempdir[ct].DIR_FirstClusterLow);
                populate_dir(tempAddr, tempdir);
                found ++;
                break;
            }
        }
        //leave if you couldn't find the directory    
        if(!found){
            printf("Could not find directory\n");
            break;
        }
        //take the next token
        token = strtok(NULL,"/");
        //check to see if the next token is NULL
        if(token == NULL){
            //show all the contents   
            for(ct = 0; ct < 16; ct ++){
                //if the attribute is 1, 16, 32 then we show it
                if(tempdir[ct].D_Att == 1  ||
                   tempdir[ct].D_Att == 16 ||
                   tempdir[ct].D_Att == 32 ){
                    printf("%s    %d Bytes\n", tempdir[ct].D_Name, tempdir[ct].DIR_FileSize);   
                }   
            }
            break;
        }
    }
    
}


void info() {
    if(!opened)
        printf("There is no file open!\n");
    else{
        
        printf("Bytes Per Sector:\n    Hex - %x\n    Decimal - %d\n", 
                byte_sec, byte_sec);
        printf("Sectors Per Clusters:\n    Hex - %x\n    Decimal - %d\n", 
                sec_clus, sec_clus);
        printf("Reserved Sector Count:\n    Hex - %x\n    Decimal - %d\n", 
                Rs_sec_cnt, Rs_sec_cnt);
        printf("Number of FAT regions:\n    Hex - %x\n    Decimal - %d\n", 
                Num_Fat, Num_Fat);
        
        printf("Sectors per FAT:\n    Hex - %x\n    Decimal - %d\n", 
                Fat32, Fat32);
        

    } 
}


void CD(){
    char tempname[15]; 
    char * token; 
    int found; 
    
    if(!opened){
        printf("There is no file open!\n");
        return;
    }
    
    if(args[0] == NULL){
        Current_Dir_Cluster_Address = Root_Dir_Cluster_Address;
        populate_dir(Current_Dir_Cluster_Address, dir);
        return;
    }
    
    token = strtok(args[0], "/");
    while(token != NULL){
        //check to see if it is valid
        if(strlen(token) > 12){
            printf("Directory does not exist\n");
            return;
        }
        //take the name and make it uppercase and spaced properly  							       
        strcpy(tempname, token);
        make_name(tempname);      
        //check it against the current directory
        found = 0;
        for(ct = 0; ct < 16; ct ++){
            if(!strcmp(dir[ct].D_Name, tempname)){
                Current_Dir_Cluster_Address = LBtoAddr(dir[ct].DIR_FirstClusterLow);
                populate_dir(Current_Dir_Cluster_Address, dir);
                found ++;
                break;
            }
        }
        //leave if you couldn't find the directory    
        if(!found){
            printf("Could not find directory '%s', stopped at 1 directory before\n", token);
            break;
        }
        //take the next token
        token = strtok(NULL, "/");
        if(token == NULL){
            break;
        }
    }
}


void read_1(){
    char * token;
    char tempname[15]; 
    int found; 
    int32_t tempAddr = Current_Dir_Cluster_Address; 
    struct EntryData tempdir[16];  
    int32_t size; 
    int16_t LB;
    int data = atoi(args[2]); 
    int BlockOff = atoi(args[1])/512; 
    int ByteOff = atoi(args[1])%512; 
    int grab; 
    char buffer[513]; 
    
    if(!opened){
        printf("There is no filesystem open!\n");
        return;
    }
    
    token = strtok(args[0], "/");
    
    while(1){
        
        if(strlen(token) > 12){
            printf("Invalid argument!\n");
            return;
        } 
        
        strcpy(tempname, token);
        
        token = strtok(NULL, "/");
        if(token == NULL){
            break;
        } 
        
        make_name(tempname);
        populate_dir(tempAddr, tempdir);
        found = 0;
        for(ct = 0; ct < 16; ct ++){
            
            if(!strcmp(tempdir[ct].D_Name, tempname)){
                tempAddr = LBtoAddr(tempdir[ct].DIR_FirstClusterLow);
                found ++;
                break;
            }
        }
       
        if(!found){
            printf("Invalid Directory Name!\n");
            return;
        }
    }
    
    make_file(tempname);
    populate_dir(tempAddr, tempdir);
    found = 0;
    for(ct = 0; ct < 16; ct ++){
        
        if(!strcmp(tempdir[ct].D_Name, tempname)){
            size = tempdir[ct].DIR_FileSize;
            LB = tempdir[ct].DIR_FirstClusterLow;
            found ++;
            break;
        }
    }
    
    if(!found){
        printf("File Not Found!\n");
        return;
    }
    
    if(size < data + atoi(args[1])){
        printf("More data requested than can be given!\n");
        return;
    }
    
    for(ct = 0; ct < BlockOff; ct ++){
        LB = next_lb(LB);
    }
    
    tempAddr = LBtoAddr(LB);
    //go to the offset
    fseek(fp, tempAddr + ByteOff, SEEK_SET);
    
    while(1){
        //choose the minimum
        if(data < 512)
            grab = data;
        else
            grab = 512;
      
        fread(buffer, 1, 512, fp);
        buffer[grab] = 0;
        //display the buffer
        //as hex values
        for(ct = 0; ct < grab; ct ++){
            printf("%x ", buffer[ct]);
        }
        
        data -= grab;
        if(data == 0){
            printf("\n");
            return;
        }
        
        LB = next_lb(LB);
        tempAddr = LBtoAddr(LB);
        
        fseek(fp, tempAddr, SEEK_SET); 
    }
}


void stat(){
    char namebuffer[20]; 
    char extbuffer[4]; 
    char statbuffer[20]; 
    char *token; 
    int whitespace; 
    int found = 0; 

    
    if(opened){
        
        if(strlen(args[0]) < 13){
            
            token = strtok(args[0], ".");
            if(token == NULL){
                printf("Not a valid filename\n");
                return;
            }
            strcpy(namebuffer, token);
            
            token = strtok(NULL, "");
            
            if(token == NULL && strlen(namebuffer) < 12){
                
                for(ct = 0; ct < 11; ct ++){
                    namebuffer[ct] = toupper(namebuffer[ct]);
                }
                
                whitespace = 11 - strlen(namebuffer);
                
                for(ct = 0; ct < whitespace; ct ++){
                    strcat(namebuffer, " ");
                }
                
                found = 0;
                for(ct = 0; ct < 16; ct ++){
                    //if you find the entry then break out
                    if(!strcmp(dir[ct].D_Name, namebuffer)){
                        //print attribute, starting cluster number, and size
                        printf("Attribute: %x\n", dir[ct].D_Att);
                        printf("Starting cluster number:\n    Hex - %x\n    Decimal - %d\n", 
                                   dir[ct].DIR_FirstClusterLow, dir[ct].DIR_FirstClusterLow);
                        //becuase it is a directory
                        printf("Size: 0 Bytes\n"); 
                        found = 1;
                        break;
                    }
                }    
                if(!found)
                    printf("Couldn't find the directory\n");
            }
            else if(strlen(token) > 3){
                printf("File extension too long (3 characters)\n");
            }
            else if(strlen(namebuffer) > 8){
                printf("File name is long (8 characters).\n");
            }
            else{
                
                whitespace = 8 - strlen(namebuffer);
                
                for(ct = 0; ct < whitespace; ct ++){
                    strcat(namebuffer, " ");
                }
                strcpy(extbuffer, token);
                
                whitespace = 3 - strlen(extbuffer);
                
                for(ct = 0; ct < whitespace; ct ++){
                    strcat(extbuffer, " ");
                }
                
                printf(statbuffer, "%s%s", namebuffer, extbuffer);
                
                for(ct = 0; ct < 11; ct ++){
                    statbuffer[ct] = toupper(statbuffer[ct]);
                }
                 
                found = 0;
                for(ct = 0; ct < 16; ct ++){
                    
                    if(!strcmp(dir[ct].D_Name, statbuffer)){
                        //print attribute, starting cluster number, and size
                        printf("Attribute: %x\n", dir[ct].D_Att);
                        printf("Starting cluster number:\n    Hex - %x\n    Decimal - %d\n", 
                                   dir[ct].DIR_FirstClusterLow, dir[ct].DIR_FirstClusterLow);
                        printf("Size: %d Bytes\n", dir[ct].DIR_FileSize); 
                        found = 1;
                        break;
                    }
                }
                if(!found)
                    printf("File not found\n");    
            }
        }
        else
            printf("That is an invalid file or directory name\n");
    }
    else
        printf("There is no filesystem open.\n");
}




int main(void) {
    // set up signal catching for control-c and control-z
    signal(SIGINT, cntl_c_handler);
    signal(SIGTSTP, cntl_z_handler);

    // allocate memory for current argument buffer
    arg = (char*) malloc(200);
    while (1) {

        
        printf("mfs(My first shell)>");

        // get user input 
        get();

        // load up first token of user input for memory allocation 
        arg = strtok(input, " ");
 
        char* base_cmd;
        base_cmd = (char*) malloc(sizeof(arg)+1);
        base_cmd = arg;

       
        ct = 0;
        do { 
            arg = strtok(NULL, " ");
           
            // allocate memory for arguments
            args[ct] = (char*) malloc(sizeof(arg)+1);
            args[ct] = arg;
            ct++;
        // loop until no more arguments
        } while(ct < 10);

       
       	if(!strcmp(base_cmd, "exit") || !strcmp(base_cmd, "quit")){
            if(opened)
                fclose(fp);
            exit (0);
        }
	
        
        if(!strcmp(base_cmd, "open")){
            //if a file isn't opened try to open a file
            if(!opened)
                open(args[0]);
            else
                printf("There is already a filesystem open!\n");
            continue;
        }
 
        
        if(!strcmp(base_cmd, "close")){
            
            if(opened){
                fclose(fp);
                printf("Closed filesystem.\n");	
                opened = 0;
            }
            else
                printf("There is no filesystem open!\n");
            continue;
        }

        
        if(!strcmp(base_cmd, "info")){
            info();
            continue;
        }

       
        if(!strcmp(base_cmd, "stat") && args[0] != NULL && args[1] == NULL){
            stat();
            continue;
        }

        
        if(!strcmp(base_cmd, "ls") && args[1] == NULL){
            ls();
            continue;
        }

        
        if(!strcmp(base_cmd, "cd") && args[1] == NULL){
            CD();
            continue;
        }

       
        if(!strcmp(base_cmd, "read") && args[1] != NULL && args[2] != NULL  && args[3] == NULL){
            read_1(); 
            continue;
        }

        
        if(!strcmp(base_cmd, "volume") && args[0] == NULL){
             if(!opened){
                 printf("There is no filesystem open!\n");
                 continue;
             }
             
             if(!strcmp(Val_lab, ""))
                 printf("Volume name not found\n");
             else
	         printf("Volume name: '%s'\n", Val_lab);
             continue;
        }

        
        if(strcmp(base_cmd, "\n"))
            printf("That isn't a valid command\n");


    }
    exit(0);
}
